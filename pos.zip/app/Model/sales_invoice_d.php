<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class sales_invoice_d extends Model
{
    protected $table = 'sales_invoice_d';
}
