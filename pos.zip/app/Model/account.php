<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class account extends Model
{
    protected $fillable = ['name' ,'type'];
}
