<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class unit extends Model
{
    protected $fillable = ['unit_name'];
}
