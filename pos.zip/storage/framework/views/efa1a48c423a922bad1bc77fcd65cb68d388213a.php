
<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title' ,'المخازن'); ?>

<div class="card">
    <div class="card-header">
        <div class="row">
            <div class="col">
                <div class="col">
                    <h6><?php echo e($stocks->name); ?></h6>
                </div>
            </div>
        </div>
    </div>
    <div class="card-body">
        <table class="table">
            <thead>
            <tr>
                <th>#</th>

                <th>المنتج</th>
                <th>الكميه</th>
            </tr>
            </thead>
            <tbody>
            <?php $i =1; ?>
            <?php $__currentLoopData = $stocks->purchase_invoice_d; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td scope="row"><?php echo e($i++); ?></td>

                    <td><?php echo e($stock->product->name); ?></td>
                    <td><?php echo e($stock->qyt); ?></td>


                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\panda180\Tower Dev\pos\resources\views/stocks/show.blade.php ENDPATH**/ ?>