<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title' ,'انشاء فاتورة مشتريات'); ?>

<div class="card">
    <div class="card-header">
        <div class="row">
            <div class="col text-center">
                <h3>فاتوره المشتريات
                #<?php echo e($invoice->id); ?>

                </h3>
            </div>
            <div class="col-1">
                <a class="btn btn-dark" href="#" role="button">طباعه</a>
            </div>
        </div>
    </div>
    <div class="card-body">
        <div class="col-md-4">
            <table class="table table-bordered">
                <tbody>
                <tr>
                    <td>المورد</td>
                    <td><?php echo e($invoice->supplier->name); ?> </td>
                </tr>
                <tr>
                    <td>المخزن</td>
                    <td><?php echo e($invoice->stock->name); ?> </td>
                </tr>
                <tr>
                    <td> التاريخ</td>
                    <td><?php echo e($invoice->created_at); ?> </td>
                </tr>
                </tbody>
            </table>
        </div>

        <hr>
        <table class="table">
            <thead>
            <tr>
                <th>#</th>
                <th>المنتج</th>
                <th>الكميه</th>
                <th> سعر الوحده</th>
                <th> المجموع</th>
                <th>الضريبه</th>
                <th>مجموع الضريبه</th>

            </tr>
            </thead>
            <tbody>
                <?php $i = 1; $vat_total = 0; ?>
            <?php $__currentLoopData = $invoice->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php  $vat_total += $product->sub_vat; ?>
                <tr>
                    <td scope="row"><?php echo e($i++); ?></td>

                    <td><?php echo e($product->product->name); ?></td>
                    <td><?php echo e($product->qyt); ?></td>
                    <td><?php echo e($product->price); ?></td>
                    <td><?php echo e($product->sub_total); ?></td>
                    <td><?php echo e($product->vat); ?></td>
                    <td><?php echo e($product->sub_vat); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <hr>
        <div class="col-md-4">
            <table class="table table-bordered">
            <tbody>
                    <tr>
                        <td>المجموع</td>
                        <td><?php echo e($invoice->total); ?> </td>
                    </tr>
                    <tr>
                        <td>الضريبه</td>
                        <td><?php echo e($vat_total); ?></td>
                    </tr>
                    <tr>
                        <td>المجموع الكلى</td>
                        <td><?php echo e($vat_total + ($invoice->total)); ?> </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
        <div class="card-footer">

        </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\panda180\Tower Dev\pos\resources\views/purchases/show.blade.php ENDPATH**/ ?>