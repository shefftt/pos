<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title' ,'التصنيفات'); ?>

<div class="card">
    <div class="card-header">
        <div class="row">
            <div class="col">
                <h6>التصنيفات</h6>
            </div>
            <div class="col text-left">
                <a class="btn btn-secondary" href="<?php echo e(url('/category/create')); ?>" role="button">اضافة تصنيف</a>

            </div>
        </div>
    </div>
    <div class="card-body">
        <table class="table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>اسم التصنيف</th>
                    <th>نوع التصنيف</th>
                    <th>الضبط</th>
                </tr>
            </thead>
            <tbody>
                <?php $i = 1; ?>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td scope="row"><?php echo e($i++); ?></td>
                    <td><?php echo e($category->name); ?></td>
                    <td>
                        <?php if(isset($category->sub->name)): ?>
                        <?php echo e($category->sub->name); ?>

                        <?php else: ?>
                        تصنيف رئيسيى
                        <?php endif; ?>
                    </td>
                    <td>
                        <a name="" id="" class="btn  btn-sm btn-primary" href="#" role="button">عرض</a>
                        <a name="" id="" class="btn  btn-sm btn-warning" href="#" role="button">تعديل</a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <center>
        <div class="card-footer">
            <div class="col-md-4">
                <?php echo e($categories->links()); ?>

            </div>
        </div>
    </center>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\panda180\Tower Dev\pos\resources\views/categories/index.blade.php ENDPATH**/ ?>