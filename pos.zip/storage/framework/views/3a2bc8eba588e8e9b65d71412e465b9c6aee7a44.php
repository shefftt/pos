<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title' ,'المنتجات'); ?>

<div class="card">
    <div class="card-header">
        <div class="row">
            <div class="col">
                <h6>المنتجات</h6>
            </div>
            <div class="col text-left">
                <a class="btn btn-secondary" href="<?php echo e(url('/product/create')); ?>" role="button">اضافة منتج</a>

            </div>
        </div>
    </div>
    <div class="card-body">
        <table class="table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>الصوره</th>
                    <th>اسم المنتج</th>
                    <th>سعر الشراء</th>
                    <th>سعر البيع</th>
                    <th>التصنيف</th>
                    <th>الضبط</th>
                </tr>
            </thead>
            <tbody>
                <?php $i = 1; ?>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($i++); ?></td>
                    <td class="col-1">
                        <img class="rounded w-100" src="<?php echo e(url('/image/')); ?>/<?php echo e($product->image); ?>">
                    </td>
                    <td><?php echo e($product->name); ?></td>
                    <td><?php echo e($product->purchase_price); ?></td>
                    <td><?php echo e($product->sale_price); ?></td>
                    <td><?php echo e($product->category->name); ?></td>
                    <td>
                        <?php if($product->status==false): ?>
                        <a name="" id="" class="btn  btn-sm btn-danger" href="<?php echo e(url('product/toggleStatus')); ?>/<?php echo e($product->id); ?>" role="button">تنشيط</a>
                        <?php else: ?>
                        <a name="" id="" class="btn  btn-sm btn-success" href="<?php echo e(url('product/toggleStatus')); ?>/<?php echo e($product->id); ?>" role="button">ايقاف</a>

                        <?php endif; ?>

                     <a name="" id="" class="btn  btn-sm btn-warning" href="<?php echo e(url('/product/edit/')); ?>/<?php echo e($product->id); ?>" role="button">تعديل</a>
                        <a name="" id="" class="btn  btn-sm btn-primary" href="<?php echo e(url('/product')); ?>/<?php echo e($product->id); ?>" role="button">عرض</a>

                    </td>


                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <center>
        <div class="card-footer">
            <div class="col-md-4">
                <?php echo e($products->links()); ?>

            </div>
        </div>
    </center>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\panda180\Tower Dev\pos\resources\views/products/index.blade.php ENDPATH**/ ?>