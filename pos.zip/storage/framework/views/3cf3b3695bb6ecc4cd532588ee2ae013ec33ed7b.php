
<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title' ,'المنتجات'); ?>

<div class="card">
    <div class="card-header">
        <div class="row">
            <div class="col">
                <h6><?php echo e($products->name); ?></h6>
            </div>
        </div>
    </div>
    <div class="card-body">
        <table class="table">
            <thead>
            <tr>
                <th>المخزن</th>
                <th>الكمية</th>
            </tr>
            </thead>
            <tbody>
                <tr>
                    <td><?php echo e($products->stock->name); ?></td>
                    <td><?php echo e($products->qyt); ?></td>

                </tr>

            </tbody>
        </table>
    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\panda180\Tower Dev\pos\resources\views/products/show.blade.php ENDPATH**/ ?>