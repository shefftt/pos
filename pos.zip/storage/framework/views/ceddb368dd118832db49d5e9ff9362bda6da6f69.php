<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title' ,'الرئيسيه'); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\panda180\Tower Dev\pos\resources\views/dashboard.blade.php ENDPATH**/ ?>