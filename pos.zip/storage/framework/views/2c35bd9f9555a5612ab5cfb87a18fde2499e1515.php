<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title' ,'العملاء'); ?>

<div class="card">
    <div class="card-header">
        <div class="row">
            <div class="col">
                <h6>العملاء</h6>
            </div>
            <div class="col text-left">
                <a class="btn btn-secondary" href="<?php echo e(url('/customer/create')); ?>" role="button">اضافة عميل</a>

            </div>
        </div>
    </div>
    <div class="card-body">
        <table class="table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>العميل</th>
                    <th> رقم الهاتف</th>
                    <th>العنوان</th>
                    <th>الحاله</th>
                    <th>الضبط</th>
                </tr>
            </thead>
            <tbody>
                <?php $i = 1; ?>
                <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td scope="row"><?php echo e($i++); ?></td>

                    <td><?php echo e($customer->name); ?></td>
                    <td><?php echo e($customer->phone); ?></td>
                    <td><?php echo e($customer->address); ?></td>
                    <td>
                        <?php if($customer->status==false): ?>

                        <span class="label badge label-sm label-danger">
                            تم الايقاف
                        </span>

                        <?php else: ?>
                        <span class="label badge label-sm label-success">
                            نشط
                        </span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <a name="" id="" class="btn  btn-sm btn-primary" href="<?php echo e(url('customer/toggleStatus')); ?>/<?php echo e($customer->id); ?>" role="button">توقيف</a>
                        <a name="" id="" class="btn  btn-sm btn-warning" href="#" role="button">عرض</a>

                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <center>
        <div class="card-footer">
            <div class="col-md-4">
                <?php echo e($customers->links()); ?>

            </div>
        </div>
    </center>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\panda180\Tower Dev\pos\resources\views/customers/index.blade.php ENDPATH**/ ?>