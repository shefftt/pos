<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title' ,'المبيعات'); ?>

<div class="card">
<div class="card-header">
        <div class="row">
            <div class="col">
                <h6>فواتير المبيعات</h6>
            </div>
            <div class="col text-left">
                <a class="btn btn-dark" target="_blank" href="<?php echo e(url('/pos')); ?>" role="button"> انشاء فاتوره</a>
                <a class="btn btn-dark" target="_blank" href="<?php echo e(url('/pos')); ?>" role="button"> بحث </a>

            </div>
        </div>
    </div>
    <div class="card-body">
        <table class="table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>العميل</th>
                    <th> المجموع</th>
                    <th> التاريخ</th>
                    <th>الضبط</th>
                </tr>
            </thead>
            <tbody>
                <?php $i = 1; ?>
                <?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td scope="row"><?php echo e($i++); ?></td>

                    <td>
                        <?php if(isset($sale->customer->name)): ?><?php echo e($sale->customer->name); ?> <?php else: ?>
                        غير معروف
                        <?php endif; ?>
                    </td>
                    <td><?php echo e($sale->total); ?></td>
                    <td><?php echo e($sale->created_at); ?></td>

                    <td>
                        <a class="btn btn-sm btn-primary" href="<?php echo e(url('/sales/')); ?>/<?php echo e($sale->id); ?>" role="button">عرض</a>

                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <center>
        <div class="card-footer">
            <div class="col-md-4">
                <?php echo e($sales->links()); ?>

            </div>
        </div>
    </center>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\panda180\Tower Dev\pos\resources\views/sales/index.blade.php ENDPATH**/ ?>