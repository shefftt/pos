<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title' ,'انشاء  فاتورة '); ?>
<purchase/>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\panda180\Tower Dev\pos\resources\views/purchases/create.blade.php ENDPATH**/ ?>