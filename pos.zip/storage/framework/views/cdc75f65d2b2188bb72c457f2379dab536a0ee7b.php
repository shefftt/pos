
<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title' ,'المخازن'); ?>

<div class="card">
    <div class="card-header">
        <div class="row">
            <div class="col">
                <h6>المخازن</h6>
            </div>
            <div class="col text-left">
                <a class="btn btn-secondary" href="<?php echo e(url('/stock/create')); ?>" role="button">اضافة مخزن </a>

            </div>
        </div>
    </div>
    <div class="card-body">
        <table class="table">
            <thead>
            <tr>
                <th>#</th>
                <th>الاسم</th>
                <th>الحالة </th>

                <th>الضبط</th>
            </tr>
            </thead>
            <tbody>
            <?php $i =1; ?>
            <?php $__currentLoopData = $stocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td scope="row"><?php echo e($i++); ?></td>

                    <td><?php echo e($stock->name); ?></td>
                    <td><?php echo e($stock->status); ?></td>

                    <td>
                        <a name="" id="" class="btn  btn-sm btn-primary" href="#" role="button">عرض</a>
                        <a name="" id="" class="btn  btn-sm btn-danger" href="#" role="button">ايقاف</a>
                        <a name="" id="" class="btn  btn-sm btn-warning" href="#" role="button">تعديل</a>

                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <center>
        <div class="card-footer">
            <div class="col-md-4">
                <?php echo e($stocks->links()); ?>

            </div>
        </div>
    </center>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\panda180\Tower Dev\pos\resources\views/stocks/index.blade.php ENDPATH**/ ?>