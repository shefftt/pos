
<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title' ,'المستخدمين'); ?>

<div class="card">
    <div class="card-header">
        <div class="row">
            <div class="col">
                <h6>المستخدمين</h6>
            </div>
            <div class="col text-left">
                <a class="btn btn-secondary" href="<?php echo e(url('/user/create')); ?>" role="button"> اضافة مستخدم </a>

            </div>
        </div>
    </div>
    <div class="card-body">
        <table class="table">
            <thead>
            <tr>
                <th>#</th>
                <th>الاسم</th>
                <th>البريد الالكتروني </th>


                <th>الضبط</th>
            </tr>
            </thead>
            <tbody>
            <?php $i =1; ?>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td scope="row"><?php echo e($i++); ?></td>
                    <!-- id 	name 	phone 	address -->
                    <td><?php echo e($user->name); ?></td>
                    <td><?php echo e($user->email); ?></td>


                    <td>


    <?php if(($user->status)==1): ?>

                             <a name="" id="" class="btn  btn-sm btn-danger" href="<?php echo e(url('/user/cancel')); ?>/<?php echo e($user->id); ?>" role="button">ايقاف</a>

                        <?php else: ?>
                            <a name="" id="" class="btn  btn-sm btn-success" href="<?php echo e(url('/user/activate')); ?>/<?php echo e($user->id); ?>" role="button">تنشيط</a>

                        <?php endif; ?>




                    </td>

                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <center>
        <div class="card-footer">
            <div class="col-md-4">
                <?php echo e($users->links()); ?>

            </div>
        </div>
    </center>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\panda180\Tower Dev\pos\resources\views/users/index.blade.php ENDPATH**/ ?>